
import tensorflow as tf

@tf.keras.utils.register_keras_serializable(package="custom")
class CombineNDandOsc(tf.keras.layers.Layer):
    """
    Combine ND spectra using learned softmax weights derived from an input embedding.
    Stores ND spectra as a non-trainable weight so the model is fully serializable.
    """
    def __init__(
        self,
        n_sections=None,
        n_bins=None,
        nd_spectra=None,
        temperature=1.0,
        dropout_rate=0.0,
        use_bias=True,
        kernel_initializer="glorot_uniform",
        bias_initializer="zeros",
        kernel_regularizer=None,
        bias_regularizer=None,
        activity_regularizer=None,
        kernel_constraint=None,
        bias_constraint=None,
        **kwargs
    ):
        super().__init__(activity_regularizer=activity_regularizer, **kwargs)

        if nd_spectra is not None:
            nd_spectra = tf.convert_to_tensor(nd_spectra, dtype=tf.keras.backend.floatx())
            if nd_spectra.shape.rank != 2:
                raise ValueError("nd_spectra must be rank-2: (n_sections, n_bins).")
            n_sections = int(nd_spectra.shape[0])
            n_bins     = int(nd_spectra.shape[1])

        if n_sections is None or n_bins is None:
            raise ValueError("Provide (n_sections, n_bins) or nd_spectra with that shape.")

        self.n_sections = int(n_sections)
        self.n_bins     = int(n_bins)
        self._nd_init_value = nd_spectra

        self.temperature = float(temperature)
        self.dropout = tf.keras.layers.Dropout(dropout_rate) if dropout_rate and dropout_rate > 0 else None

        self.proj = tf.keras.layers.Dense(
            self.n_sections,
            use_bias=use_bias,
            kernel_initializer=kernel_initializer,
            bias_initializer=bias_initializer,
            kernel_regularizer=kernel_regularizer,
            bias_regularizer=bias_regularizer,
            kernel_constraint=kernel_constraint,
            bias_constraint=bias_constraint,
            name="section_logits",
        )

    def build(self, input_shape):
        if self._nd_init_value is not None:
            initializer = tf.keras.initializers.Constant(self._nd_init_value)
        else:
            initializer = tf.keras.initializers.Zeros()

        self.nd_spectra = self.add_weight(
            name="nd_spectra",
            shape=(self.n_sections, self.n_bins),
            dtype=self.dtype,
            initializer=initializer,
            trainable=False,
        )
        super().build(input_shape)

    def call(self, z, training=None):
        if self.dropout is not None:
            z = self.dropout(z, training=training)

        logits = self.proj(z)
        if self.temperature is not None and self.temperature > 0:
            logits = logits / self.temperature
        weights = tf.nn.softmax(logits, axis=-1)

        fd = tf.linalg.matmul(weights, self.nd_spectra)
        return fd

    def compute_output_shape(self, input_shape):
        batch = input_shape[0] if isinstance(input_shape, (tuple, list)) else None
        return (batch, self.n_bins)

    def get_config(self):
        config = super().get_config()
        config.update({
            "n_sections": self.n_sections,
            "n_bins": self.n_bins,
            "nd_spectra": None,
            "temperature": self.temperature,
            "dropout_rate": (self.dropout.rate if self.dropout is not None else 0.0),
            "use_bias": self.proj.use_bias,
            "kernel_initializer": tf.keras.initializers.serialize(self.proj.kernel_initializer),
            "bias_initializer": tf.keras.initializers.serialize(self.proj.bias_initializer),
            "kernel_regularizer": tf.keras.regularizers.serialize(self.proj.kernel_regularizer),
            "bias_regularizer": tf.keras.regularizers.serialize(self.proj.bias_regularizer),
            "activity_regularizer": tf.keras.regularizers.serialize(self.activity_regularizer),
            "kernel_constraint": tf.keras.constraints.serialize(self.proj.kernel_constraint),
            "bias_constraint": tf.keras.constraints.serialize(self.proj.bias_constraint),
        })
        return config

    @classmethod
    def from_config(cls, config):
        return cls(**config)
